package vn.sapo.payment.method.dto;

public class UpdatePaymentMethodParam {
}
