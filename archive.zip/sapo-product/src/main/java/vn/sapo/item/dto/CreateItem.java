package vn.sapo.item.dto;

import lombok.*;
import lombok.experimental.Accessors;

@Getter
@Setter
@Accessors(chain = true)
public class CreateItem {
    private Integer id;

}
