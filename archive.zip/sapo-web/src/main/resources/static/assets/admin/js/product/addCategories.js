let page = {
    urls: {
        addCategories: "http://localhost:8080/api/categories/create"
    },
    elements: {},
    commands: {},
    initializeEventControl: {}
}

function addCategories() {
    console.log("addCategories =====>");

}
