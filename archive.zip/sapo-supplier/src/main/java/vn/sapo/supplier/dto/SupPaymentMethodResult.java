package vn.sapo.supplier.dto;

public class SupPaymentMethodResult {
    private Integer id;
    private Integer fullName;
}
