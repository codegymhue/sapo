package vn.sapo.order.purchase.dto;

public class PurchaseOrderParam {
}
