package vn.sapo.order.shared;

public class OrderEmployeeResult {
}
