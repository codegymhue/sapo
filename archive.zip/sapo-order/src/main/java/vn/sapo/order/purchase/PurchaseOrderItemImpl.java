package vn.sapo.order.purchase;

public class PurchaseOrderItemImpl implements PurchaseOrderItemService {
}