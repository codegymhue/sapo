package vn.sapo.order.purchase.dto;

import org.springframework.stereotype.Component;
import vn.sapo.entities.order.purchase.PurchaseOrder;

@Component
public class PurchaseOrderMapper {

    public PurchaseOrderResult  toDTO(PurchaseOrder purchaseOrder) {
        return null;
    }
}
