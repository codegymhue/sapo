package vn.sapo.order.purchase;

public interface PurchaseOrderItemService {

}
