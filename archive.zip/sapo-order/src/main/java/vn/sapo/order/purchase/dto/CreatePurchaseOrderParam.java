package vn.sapo.order.purchase.dto;

import java.math.BigDecimal;

public class CreatePurchaseOrderParam {

    private Integer id;

    private BigDecimal paid;
}
