package vn.sapo.entities.product.variation;

public class Variation_Item {
}
