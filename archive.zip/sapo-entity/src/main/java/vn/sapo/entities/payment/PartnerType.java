package vn.sapo.entities.payment;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import javax.persistence.*;

@Setter
@NoArgsConstructor
@Accessors(chain = true)
@Entity
@Table(name = "partner_type")
public class PartnerType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "name", nullable = false, length = 50)
    private String name;

    public PartnerType(Integer id) {
        this.id = id;
    }


}