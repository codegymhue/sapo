package vn.sapo.exceptions;

public class VersionException extends Exception {
    public VersionException(String message) {
        super(message);
    }
}
